Bushido Finance — September 2026 social posts, revised typography

Six posts in PNG and JPG, 1080 × 1350.
Regular and medium Inter typography, wider margins and line spacing, original Bushido logo at top left.
Original tactile paper, document and architectural visual concepts retained.
All 61 original text blocks retained exactly, verified against the artwork embedded in the September content calendar.
Australian spelling, figures, dates, footnotes, labels and website addresses preserved.
These are finished flattened raster graphics.
